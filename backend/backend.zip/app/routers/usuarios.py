# app/routers/usuarios.py
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Usuario
from app.auth import get_password_hash, get_current_user  # get_current_user ya existe
# ↑ si no lo usás en este archivo, no pasa nada; queda importado para futuros endpoints

router = APIRouter(prefix="/usuarios", tags=["usuarios"])

# ===== Schemas locales mínimos para no romper nada =====
class UsuarioOut(BaseModel):
    id: int
    username: str
    email: EmailStr
    rol: str | None = "cliente"
    created_at: datetime | None = None

    class Config:
        from_attributes = True  # Pydantic v2

class RegisterIn(BaseModel):
    email: EmailStr
    username: str = Field(min_length=3, max_length=30, pattern=r"^[a-zA-Z0-9._-]+$")
    password: str = Field(min_length=8)
    rol: str | None = "cliente"

# ===== Registro =====
@router.post("/registro", status_code=201, response_model=UsuarioOut)
def registro(payload: RegisterIn, db: Session = Depends(get_db)):
    # duplicados
    if db.query(Usuario).filter(Usuario.username == payload.username).first():
        raise HTTPException(status_code=409, detail="Ese usuario ya existe.")
    if db.query(Usuario).filter(Usuario.email == payload.email).first():
        raise HTTPException(status_code=409, detail="Ese correo ya está registrado.")

    # hash
    hashed = get_password_hash(payload.password)

    # crear
    user = Usuario(
        username=payload.username,
        email=payload.email,
        hashed_password=hashed,
        rol=payload.rol or "cliente",
        created_at=datetime.utcnow(),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user
