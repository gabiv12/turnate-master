from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.deps import get_current_emprendedor
from app import models
from app.schemas import HorarioBase, HorarioOut

router = APIRouter(prefix="/horarios", tags=["horarios"])

@router.get("/mis", response_model=List[HorarioOut])
def mis(db: Session = Depends(get_db), emp: models.Emprendedor = Depends(get_current_emprendedor)):
    return db.query(models.Horario).filter(models.Horario.emprendedor_id == emp.id).order_by(models.Horario.dia_semana, models.Horario.hora_desde).all()

@router.post("", response_model=HorarioOut, status_code=201)
def crear(payload: HorarioBase, db: Session = Depends(get_db), emp: models.Emprendedor = Depends(get_current_emprendedor)):
    h = models.Horario(emprendedor_id=emp.id, **payload.model_dump())
    db.add(h); db.commit(); db.refresh(h)
    return h
