# app/routers/turnos.py
from __future__ import annotations
from datetime import datetime, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Path
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from app.database import get_db
from app import models
from app.schemas import TurnoOut, TurnoCompatCreate, TurnoUpdate
from app.auth import get_current_user  # Debe existir en tu auth.py (devuelve dict/obj con id y rol)

router = APIRouter(prefix="/turnos", tags=["turnos"])

# --------- helpers ---------
def _first_serv_duracion(serv) -> int:
    # intenta varias convenciones
    for k in ("duracion_min", "duracion_minutos", "duracion"):
        if hasattr(serv, k) and getattr(serv, k) is not None:
            try:
                return int(getattr(serv, k))
            except Exception:
                pass
    return 30

def _emp_for_user(db: Session, user_id: int) -> Optional[models.Emprendedor]:
    return db.query(models.Emprendedor).filter(models.Emprendedor.usuario_id == user_id).first()

def _emp_by_code(db: Session, code: str) -> Optional[models.Emprendedor]:
    return db.query(models.Emprendedor).filter(models.Emprendedor.codigo_cliente == code.upper()).first()

def _overlap_exists(db: Session, emprendedor_id: int, inicio: datetime, fin: datetime, exclude_id: Optional[int] = None) -> bool:
    q = db.query(models.Turno).filter(
        models.Turno.emprendedor_id == emprendedor_id,
        models.Turno.inicio < fin,
        models.Turno.fin > inicio,
    )
    if exclude_id:
        q = q.filter(models.Turno.id != exclude_id)
    return db.query(q.exists()).scalar()

def _to_out(turno: models.Turno) -> dict:
    return {
        "id": turno.id,
        "inicio": turno.inicio,
        "fin": turno.fin,
        "servicio_id": getattr(turno, "servicio_id", None),
        "cliente_nombre": (getattr(turno, "cliente_nombre", "") or "").strip(),
        "notas": getattr(turno, "notas", "") or "",
        "duracion_minutos": getattr(turno, "duracion_minutos", None),
    }

# --------- GETs ---------
@router.get("/mis", response_model=List[TurnoOut])
def turnos_mios(
    desde: datetime = Query(default=None),
    hasta: datetime = Query(default=None),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    """
    Si el usuario es emprendedor => devuelve sus turnos.
    Si es cliente y tu modelo aún no guarda cliente_id => devuelve [] para no romper el front.
    """
    u_id = int(user["id"])
    emp = _emp_for_user(db, u_id)
    if not emp:
        return []

    if not desde or not hasta:
        now = datetime.utcnow()
        desde = datetime(now.year, now.month, 1)
        # fin de mes:
        if now.month == 12:
            hasta = datetime(now.year + 1, 1, 1)
        else:
            hasta = datetime(now.year, now.month + 1, 1)

    q = (
        db.query(models.Turno)
        .filter(
            models.Turno.emprendedor_id == emp.id,
            models.Turno.inicio >= desde,
            models.Turno.inicio < hasta,
        )
        .order_by(models.Turno.inicio.asc())
    )
    return [_to_out(t) for t in q.all()]

@router.get("/owner", response_model=List[TurnoOut])
def turnos_owner(
    desde: datetime = Query(default=None),
    hasta: datetime = Query(default=None),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    # Alias de /mis para dueños (lo dejo explícito por compatibilidad con tu front)
    return turnos_mios(desde=desde, hasta=hasta, db=db, user=user)

# --------- POST compat (dueño) ---------
@router.post("/compat", response_model=TurnoOut, status_code=201)
def crear_turno_owner(
    payload: TurnoCompatCreate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    u_id = int(user["id"])
    emp = _emp_for_user(db, u_id)
    if not emp and payload.emprendedor_id:
        emp = db.query(models.Emprendedor).get(payload.emprendedor_id)
    if not emp:
        raise HTTPException(status_code=404, detail="No sos emprendedor o no existe el emprendimiento")

    serv = db.query(models.Servicio).get(payload.servicio_id)
    if not serv or serv.emprendedor_id != emp.id:
        raise HTTPException(status_code=404, detail="Servicio no encontrado en tu emprendimiento")

    inicio = payload.datetime
    dur = _first_serv_duracion(serv)
    fin = inicio + timedelta(minutes=dur)

    if _overlap_exists(db, emp.id, inicio, fin):
        raise HTTPException(status_code=409, detail="Ese horario ya está ocupado")

    t = models.Turno(
        emprendedor_id=emp.id,
        servicio_id=serv.id,
        inicio=inicio,
        fin=fin,
        cliente_nombre=(payload.cliente_nombre or "").strip(),
        notas=(payload.notas or "").strip(),
        duracion_minutos=dur,
    )
    db.add(t)
    db.commit()
    db.refresh(t)
    return _to_out(t)

# --------- POST compat por código (cliente público) ---------
@router.post("/compat/{codigo}", response_model=TurnoOut, status_code=201)
def crear_turno_publico(
    codigo: str,
    payload: TurnoCompatCreate,
    db: Session = Depends(get_db),
):
    emp = _emp_by_code(db, codigo)
    if not emp:
        raise HTTPException(status_code=404, detail="Emprendimiento no encontrado")

    serv = db.query(models.Servicio).get(payload.servicio_id)
    if not serv or serv.emprendedor_id != emp.id:
        raise HTTPException(status_code=404, detail="Servicio no disponible para este emprendimiento")

    inicio = payload.datetime
    dur = _first_serv_duracion(serv)
    fin = inicio + timedelta(minutes=dur)

    if _overlap_exists(db, emp.id, inicio, fin):
        raise HTTPException(status_code=409, detail="Ese horario ya está reservado")

    t = models.Turno(
        emprendedor_id=emp.id,
        servicio_id=serv.id,
        inicio=inicio,
        fin=fin,
        cliente_nombre=(payload.cliente_nombre or "").strip(),
        notas=(payload.notas or "").strip(),
        duracion_minutos=dur,
    )
    db.add(t)
    db.commit()
    db.refresh(t)
    return _to_out(t)

# --------- PATCH / DELETE ---------
@router.patch("/{turno_id}", response_model=TurnoOut)
def actualizar_turno(
    turno_id: int = Path(..., gt=0),
    cambios: TurnoUpdate = None,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    u_id = int(user["id"])
    emp = _emp_for_user(db, u_id)
    if not emp:
        raise HTTPException(status_code=403, detail="No sos emprendedor")

    t = db.query(models.Turno).get(turno_id)
    if not t or t.emprendedor_id != emp.id:
        raise HTTPException(status_code=404, detail="Turno no encontrado")

    inicio = cambios.inicio or t.inicio
    fin = cambios.fin or t.fin

    # Si cambió el servicio, recalculamos duración por seguridad
    if cambios.servicio_id:
        serv = db.query(models.Servicio).get(cambios.servicio_id)
        if not serv or serv.emprendedor_id != emp.id:
            raise HTTPException(status_code=404, detail="Servicio inválido")
        dur = _first_serv_duracion(serv)
        # si el usuario no envió fin explícito, ajusto con la duración del nuevo servicio
        if cambios.fin is None and cambios.inicio is not None:
            fin = inicio + timedelta(minutes=dur)
        t.servicio_id = serv.id
        t.duracion_minutos = dur

    if _overlap_exists(db, emp.id, inicio, fin, exclude_id=t.id):
        raise HTTPException(status_code=409, detail="Ese horario se superpone con otro turno")

    t.inicio = inicio
    t.fin = fin
    if cambios.cliente_nombre is not None:
        t.cliente_nombre = (cambios.cliente_nombre or "").strip()
    if cambios.notas is not None:
        t.notas = (cambios.notas or "").strip()

    db.commit()
    db.refresh(t)
    return _to_out(t)

@router.delete("/{turno_id}", status_code=204)
def eliminar_turno(
    turno_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    u_id = int(user["id"])
    emp = _emp_for_user(db, u_id)
    if not emp:
        raise HTTPException(status_code=403, detail="No sos emprendedor")

    t = db.query(models.Turno).get(turno_id)
    if not t or t.emprendedor_id != emp.id:
        raise HTTPException(status_code=404, detail="Turno no encontrado")

    db.delete(t)
    db.commit()
    return
