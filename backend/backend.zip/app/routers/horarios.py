# app/routers/horarios.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models
from app.schemas import HorarioCreate, HorarioUpdate, HorarioOut
from app.auth import get_current_user

router = APIRouter(prefix="/horarios", tags=["horarios"])

def _ensure_emp(db: Session, user: models.Usuario) -> models.Emprendedor:
    emp = db.query(models.Emprendedor).filter(models.Emprendedor.usuario_id == user.id).first()
    if emp:
        return emp
    emp = models.Emprendedor(usuario_id=user.id, nombre=user.username or "Mi Emprendimiento", codigo_cliente="TEMP")
    db.add(emp)
    db.commit()
    db.refresh(emp)
    return emp

@router.get("/mis", response_model=list[HorarioOut])
def mis_horarios(db: Session = Depends(get_db), user: models.Usuario = Depends(get_current_user)):
    emp = _ensure_emp(db, user)
    return (
        db.query(models.Horario)
        .filter(models.Horario.emprendedor_id == emp.id)
        .order_by(models.Horario.dia_semana.asc(), models.Horario.hora_desde.asc())
        .all()
    )

@router.post("", response_model=HorarioOut, status_code=201)
def crear_horario(payload: HorarioCreate, db: Session = Depends(get_db), user: models.Usuario = Depends(get_current_user)):
    emp = _ensure_emp(db, user)
    h = models.Horario(
        emprendedor_id=emp.id,
        dia_semana=payload.dia_semana,
        hora_desde=payload.hora_desde,
        hora_hasta=payload.hora_hasta,
        intervalo_min=getattr(payload, "intervalo_min", 30),
        activo=getattr(payload, "activo", True),
    )
    db.add(h)
    db.commit()
    db.refresh(h)
    return h

@router.put("/{horario_id}", response_model=HorarioOut)
def actualizar_horario(horario_id: int, payload: HorarioUpdate, db: Session = Depends(get_db), user: models.Usuario = Depends(get_current_user)):
    emp = _ensure_emp(db, user)
    h = (
        db.query(models.Horario)
        .filter(models.Horario.id == horario_id, models.Horario.emprendedor_id == emp.id)
        .first()
    )
    if not h:
        raise HTTPException(status_code=404, detail="Horario no encontrado")

    data = payload.model_dump(exclude_unset=True)
    for k, v in data.items():
        if hasattr(h, k):
            setattr(h, k, v)

    db.add(h)
    db.commit()
    db.refresh(h)
    return h

@router.delete("/{horario_id}", status_code=204)
def eliminar_horario(horario_id: int, db: Session = Depends(get_db), user: models.Usuario = Depends(get_current_user)):
    emp = _ensure_emp(db, user)
    h = (
        db.query(models.Horario)
        .filter(models.Horario.id == horario_id, models.Horario.emprendedor_id == emp.id)
        .first()
    )
    if not h:
        raise HTTPException(status_code=404, detail="Horario no encontrado")
    db.delete(h)
    db.commit()
    return
