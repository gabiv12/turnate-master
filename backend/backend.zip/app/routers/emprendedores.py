# app/routers/emprendedores.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app import models, schemas
from app.deps import get_db, get_current_user
from datetime import datetime
import secrets
import string

router = APIRouter(prefix="/emprendedores", tags=["emprendedores"])


def _gen_codigo_cliente(n=8):
    alfabeto = string.ascii_uppercase + string.digits
    return "".join(secrets.choice(alfabeto) for _ in range(n))


def _ensure_emprendedor_for_user(db: Session, user):
    Emp = models.Emprendedor

    # --- 1) Buscar por el campo disponible en el modelo ---
    if hasattr(Emp, "usuario_id"):
        emp = db.query(Emp).filter(Emp.usuario_id == user.id).first()
    elif hasattr(Emp, "usuario"):
        # Esquema viejo: guarda el username como texto
        emp = db.query(Emp).filter(Emp.usuario == user.username).first()
    elif hasattr(Emp, "codigo_cliente"):
        # Último recurso: intenta por código igual al username (por compat)
        emp = db.query(Emp).filter(Emp.codigo_cliente == user.username).first()
    else:
        emp = None

    if emp:
        return emp

    # --- 2) Crear uno nuevo de forma compatible con múltiples esquemas ---
    data = {}

    # Relación/FK si existe
    if hasattr(Emp, "usuario_id"):
        data["usuario_id"] = user.id
    elif hasattr(Emp, "usuario"):
        data["usuario"] = user.username  # campo texto

    # Nombre (algunos esquemas lo tienen NOT NULL)
    if hasattr(Emp, "nombre"):
        data["nombre"] = getattr(user, "username", "Mi Emprendimiento")

    # Campos comunes si existen
    if hasattr(Emp, "negocio") and "nombre" not in data:
        data["negocio"] = getattr(user, "username", "Mi Emprendimiento")

    if hasattr(Emp, "descripcion"):
        data["descripcion"] = "Creado automáticamente"

    if hasattr(Emp, "codigo_cliente"):
        # Si no hay código, generamos uno único
        codigo = _gen_codigo_cliente()
        # Intento evitar colisión rápida (poco probable)
        tries = 0
        while db.query(Emp).filter(Emp.codigo_cliente == codigo).first() and tries < 3:
            codigo = _gen_codigo_cliente()
            tries += 1
        data["codigo_cliente"] = codigo

    # Timestamps si existen
    now = datetime.utcnow()
    if hasattr(Emp, "created_at"):
        data["created_at"] = now
    if hasattr(Emp, "updated_at"):
        data["updated_at"] = now

    emp = Emp(**data)
    db.add(emp)
    db.commit()
    db.refresh(emp)
    return emp


@router.get("/mi", response_model=schemas.EmprendedorOut)
def get_mi(db: Session = Depends(get_db), user=Depends(get_current_user)):
    try:
        return _ensure_emprendedor_for_user(db, user)
    except Exception as e:
        # Logueá e y devolvé 500 legible si querés
        raise HTTPException(status_code=500, detail=f"Error resolviendo emprendedor: {e}")


@router.put("/mi", response_model=schemas.EmprendedorOut)
def put_mi(
    payload: schemas.EmprendedorUpdate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    emp = _ensure_emprendedor_for_user(db, user)

    # Actualizamos solo atributos existentes en el modelo
    for k, v in payload.model_dump(exclude_unset=True).items():
        if hasattr(emp, k):
            setattr(emp, k, v)

    if hasattr(emp, "updated_at"):
        emp.updated_at = datetime.utcnow()

    db.add(emp)
    db.commit()
    db.refresh(emp)
    return emp
