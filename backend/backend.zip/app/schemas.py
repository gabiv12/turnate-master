# app/schemas.py
from typing import Optional, List
from datetime import datetime, time
from pydantic import BaseModel, EmailStr, Field

# ------------------ USUARIO ------------------

class UsuarioRegister(BaseModel):
    username: str = Field(..., min_length=3, max_length=30)
    password: str = Field(..., min_length=6, max_length=128)
    email: Optional[EmailStr] = None
    rol: Optional[str] = None  # por defecto lo setea el backend

class UsuarioOut(BaseModel):
    id: int
    username: str
    email: Optional[EmailStr] = None
    rol: Optional[str] = None

    model_config = {"from_attributes": True}

class UsuarioUpdate(BaseModel):
    email: Optional[EmailStr] = None
    username: Optional[str] = Field(default=None, min_length=3, max_length=30)

class PasswordChange(BaseModel):
    old_password: str
    new_password: str = Field(..., min_length=6, max_length=128)

class LoginIn(BaseModel):
    username: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UsuarioOut

# ------------------ EMPRENDEDOR ------------------

class EmprendedorBase(BaseModel):
    nombre: Optional[str] = None
    descripcion: Optional[str] = None
    telefono: Optional[str] = None
    direccion: Optional[str] = None
    barrio: Optional[str] = None
    ciudad: Optional[str] = None
    provincia: Optional[str] = None
    pais: Optional[str] = None
    logo_url: Optional[str] = None
    logo: Optional[str] = None

class EmprendedorUpdate(EmprendedorBase):
    pass

class EmprendedorOut(EmprendedorBase):
    id: int
    usuario_id: int
    codigo_cliente: str

    model_config = {"from_attributes": True}

# ------------------ SERVICIO ------------------

class ServicioBase(BaseModel):
    nombre: str
    precio: Optional[float] = 0.0
    duracion_min: Optional[int] = 30
    activo: Optional[bool] = True

class ServicioCreate(ServicioBase):
    pass

class ServicioUpdate(BaseModel):
    nombre: Optional[str] = None
    precio: Optional[float] = None
    duracion_min: Optional[int] = None
    activo: Optional[bool] = None

class ServicioOut(ServicioBase):
    id: int
    emprendedor_id: int

    model_config = {"from_attributes": True}

# ------------------ HORARIO ------------------

class HorarioBase(BaseModel):
    dia_semana: int            # 0..6 (Domingo=0)
    hora_desde: time
    hora_hasta: time
    intervalo_min: Optional[int] = 30
    activo: Optional[bool] = True

class HorarioCreate(HorarioBase):
    pass

class HorarioUpdate(BaseModel):
    dia_semana: Optional[int] = None
    hora_desde: Optional[time] = None
    hora_hasta: Optional[time] = None
    intervalo_min: Optional[int] = None
    activo: Optional[bool] = None

class HorarioOut(HorarioBase):
    id: int
    emprendedor_id: int

    model_config = {"from_attributes": True}

# ------------------ TURNO ------------------

class TurnoBase(BaseModel):
    inicio: datetime
    fin: datetime
    servicio_id: int
    cliente_nombre: Optional[str] = ""
    notas: Optional[str] = ""

class TurnoUpdate(BaseModel):
    inicio: Optional[datetime] = None
    fin: Optional[datetime] = None
    servicio_id: Optional[int] = None
    cliente_nombre: Optional[str] = None
    notas: Optional[str] = None

class TurnoOut(TurnoBase):
    id: int
    emprendedor_id: int

    model_config = {"from_attributes": True}

# compat para /turnos/compat
class TurnoCompatCreate(BaseModel):
    datetime: datetime
    servicio_id: int
    cliente_nombre: Optional[str] = ""
    notas: Optional[str] = ""
